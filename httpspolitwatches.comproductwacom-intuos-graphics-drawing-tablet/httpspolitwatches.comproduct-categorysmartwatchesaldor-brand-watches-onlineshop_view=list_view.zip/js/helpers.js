var machicThemeModule = {};
/* global machic_settings */

(function($) {

	machicThemeModule.$window = $(window);

	machicThemeModule.$document = $(document);

	machicThemeModule.$body = $('body');


	
})(jQuery);